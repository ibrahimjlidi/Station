import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

import { db } from '../../lib/db.js';
import {
  authMiddleware,
  requireRole,
  type AuthRequest,
} from '../../middleware/auth.js';

import {
  changePasswordSchema,
  loginSchema,
  resetPasswordSchema,
  userCreateSchema,
  userUpdateSchema,
} from './schemas.js';

const router = Router();

export const usersRouter = Router();

const getSecret = () =>
  process.env.JWT_SECRET ?? 'development-secret';

/**
 * Utilisateur public
 * On ne retourne JAMAIS passwordHash
 */
type PublicUser = {
  id: number;
  username: string;
  nom: string;
  prenom: string;
  telephone: string | null;
  role: 'gerant' | 'caissier' | 'vendeur';
  actif: boolean;
  lastLoginAt: Date | null;
  magasinId: number | null;
};

/**
 * Création du JWT
 */
function createToken(user: {
  id: number;
  username: string;
  role: 'gerant' | 'caissier' | 'vendeur';
  magasinId: number | null;
}) {
  return jwt.sign(
    {
      id: user.id,
      username: user.username,
      role: user.role,
      magasinId: user.magasinId,
    },
    getSecret(),
    {
      expiresIn: '8h',
    }
  );
}

/**
 * Convertit une ligne MySQL en utilisateur public.
 */
function toPublicUser(user: any): PublicUser {
  return {
    id: Number(user.id),
    username: user.username,
    nom: user.nom,
    prenom: user.prenom,
    telephone: user.telephone ?? null,
    role: user.role,
    actif: Boolean(user.actif),
    lastLoginAt: user.lastLoginAt ?? null,
    magasinId:
      user.magasinId !== null && user.magasinId !== undefined
        ? Number(user.magasinId)
        : null,
  };
}

/**
 * ============================================================
 * LOGIN
 * ============================================================
 */
router.post('/login', async (request, response, next) => {
  try {
    const input = loginSchema.parse(request.body);

    const [rows] = await db.query(
      `
      SELECT
        id,
        username,
        passwordHash,
        nom,
        prenom,
        telephone,
        role,
        actif,
        lastLoginAt,
        magasinId
      FROM user
      WHERE username = ?
      LIMIT 1
      `,
      [input.username]
    );

    const users = rows as any[];

    if (users.length === 0) {
      response.status(401).json({
        message: 'Identifiants invalides.',
      });
      return;
    }

    const user = users[0];

    /**
     * Vérification du mot de passe
     */
    const passwordValid = await bcrypt.compare(
      input.password,
      user.passwordHash
    );

    if (!passwordValid) {
      response.status(401).json({
        message: 'Identifiants invalides.',
      });
      return;
    }

    /**
     * Vérification compte actif
     */
    if (!Boolean(user.actif)) {
      response.status(403).json({
        message: 'Compte désactivé, contactez le gérant.',
      });
      return;
    }

    /**
     * Mise à jour de la dernière connexion
     */
    await db.query(
      `
      UPDATE user
      SET lastLoginAt = NOW()
      WHERE id = ?
      `,
      [user.id]
    );

    const publicUser = toPublicUser({
      ...user,
      lastLoginAt: new Date(),
    });

    const token = createToken({
      id: Number(user.id),
      username: user.username,
      role: user.role,
      magasinId:
        user.magasinId !== null && user.magasinId !== undefined
          ? Number(user.magasinId)
          : null,
    });

    response.json({
      user: publicUser,
      token,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * ============================================================
 * GET USERS
 * ============================================================
 */
usersRouter.get(
  '/users',
  authMiddleware,
  requireRole('gerant'),
  async (request: AuthRequest, response, next) => {
    try {
      /**
       * On limite les utilisateurs au magasin du gérant.
       */
      const magasinId = request.user?.magasinId;

      let sql = `
        SELECT
          id,
          username,
          nom,
          prenom,
          telephone,
          role,
          actif,
          lastLoginAt,
          magasinId
        FROM user
      `;

      const params: any[] = [];

      if (magasinId !== null && magasinId !== undefined) {
        sql += ` WHERE magasinId = ? `;
        params.push(magasinId);
      }

      sql += `
        ORDER BY nom ASC, prenom ASC
      `;

      const [rows] = await db.query(sql, params);

      const users = (rows as any[]).map(toPublicUser);

      response.json(users);
    } catch (error) {
      next(error);
    }
  }
);

/**
 * ============================================================
 * CREATE USER
 * ============================================================
 */
usersRouter.post(
  '/users',
  authMiddleware,
  requireRole('gerant'),
  async (request: AuthRequest, response, next) => {
    try {
      const input = userCreateSchema.parse(request.body);

      /**
       * Vérifier si username existe déjà
       */
      const [existingRows] = await db.query(
        `
        SELECT id
        FROM user
        WHERE username = ?
        LIMIT 1
        `,
        [input.username]
      );

      const existingUsers = existingRows as any[];

      if (existingUsers.length > 0) {
        response.status(409).json({
          message: 'Ce nom d’utilisateur existe déjà.',
        });
        return;
      }

      /**
       * Hash du mot de passe
       */
      const passwordHash = await bcrypt.hash(
        input.password,
        12
      );

      const magasinId =
        request.user?.magasinId ?? null;

      /**
       * Création utilisateur
       */
      const [result] = await db.query(
        `
        INSERT INTO user
        (
          username,
          passwordHash,
          nom,
          prenom,
          telephone,
          role,
          actif,
          magasinId
        )
        VALUES (?, ?, ?, ?, ?, ?, 1, ?)
        `,
        [
          input.username,
          passwordHash,
          input.nom,
          input.prenom,
          input.telephone ?? null,
          input.role,
          magasinId,
        ]
      );

      const insertResult = result as any;

      const userId = insertResult.insertId;

      /**
       * Récupérer l'utilisateur créé
       */
      const [rows] = await db.query(
        `
        SELECT
          id,
          username,
          nom,
          prenom,
          telephone,
          role,
          actif,
          lastLoginAt,
          magasinId
        FROM user
        WHERE id = ?
        LIMIT 1
        `,
        [userId]
      );

      const users = rows as any[];

      if (users.length === 0) {
        response.status(500).json({
          message: 'Utilisateur créé mais impossible de le récupérer.',
        });
        return;
      }

      response.status(201).json(
        toPublicUser(users[0])
      );
    } catch (error) {
      next(error);
    }
  }
);

/**
 * ============================================================
 * UPDATE USER
 * ============================================================
 */
usersRouter.put(
  '/users/:id',
  authMiddleware,
  requireRole('gerant'),
  async (request: AuthRequest, response, next) => {
    try {
      const id = Number(request.params.id);

      if (!Number.isInteger(id) || id <= 0) {
        response.status(400).json({
          message: 'ID utilisateur invalide.',
        });
        return;
      }

      /**
       * Un gérant ne peut pas désactiver son propre compte
       */
      if (
        request.user?.id === id &&
        request.body.actif === false
      ) {
        response.status(400).json({
          message:
            'Un gérant ne peut pas désactiver son propre compte.',
        });
        return;
      }

      /**
       * Vérifier que l'utilisateur existe
       * dans le même magasin.
       */
      const magasinId = request.user?.magasinId;

      let findSql = `
        SELECT
          id,
          username,
          nom,
          prenom,
          telephone,
          role,
          actif,
          lastLoginAt,
          magasinId
        FROM user
        WHERE id = ?
      `;

      const findParams: any[] = [id];

      if (
        magasinId !== null &&
        magasinId !== undefined
      ) {
        findSql += ` AND magasinId = ? `;
        findParams.push(magasinId);
      }

      findSql += ` LIMIT 1 `;

      const [targetRows] = await db.query(
        findSql,
        findParams
      );

      const targets = targetRows as any[];

      if (targets.length === 0) {
        response.status(404).json({
          message: 'Utilisateur introuvable.',
        });
        return;
      }

      /**
       * Validation des données
       */
      const input = userUpdateSchema.parse(
        request.body
      );

      /**
       * Construction dynamique de l'UPDATE
       */
      const fields: string[] = [];
      const values: any[] = [];

      if (input.username !== undefined) {
        fields.push('username = ?');
        values.push(input.username);
      }

      if (input.nom !== undefined) {
        fields.push('nom = ?');
        values.push(input.nom);
      }

      if (input.prenom !== undefined) {
        fields.push('prenom = ?');
        values.push(input.prenom);
      }

      if (input.telephone !== undefined) {
        fields.push('telephone = ?');
        values.push(input.telephone);
      }

      if (input.role !== undefined) {
        fields.push('role = ?');
        values.push(input.role);
      }

      if (input.actif !== undefined) {
        fields.push('actif = ?');
        values.push(input.actif);
      }

      /**
       * Rien à modifier
       */
      if (fields.length === 0) {
        response.json(
          toPublicUser(targets[0])
        );
        return;
      }

      /**
       * Vérifier username si modification
       */
      if (input.username !== undefined) {
        const [duplicateRows] = await db.query(
          `
          SELECT id
          FROM user
          WHERE username = ?
          AND id <> ?
          LIMIT 1
          `,
          [input.username, id]
        );

        const duplicates =
          duplicateRows as any[];

        if (duplicates.length > 0) {
          response.status(409).json({
            message:
              'Ce nom d’utilisateur existe déjà.',
          });
          return;
        }
      }

      values.push(id);

      await db.query(
        `
        UPDATE user
        SET ${fields.join(', ')}
        WHERE id = ?
        `,
        values
      );

      /**
       * Récupérer utilisateur après modification
       */
      const [updatedRows] = await db.query(
        `
        SELECT
          id,
          username,
          nom,
          prenom,
          telephone,
          role,
          actif,
          lastLoginAt,
          magasinId
        FROM user
        WHERE id = ?
        LIMIT 1
        `,
        [id]
      );

      const updatedUsers =
        updatedRows as any[];

      response.json(
        toPublicUser(updatedUsers[0])
      );
    } catch (error) {
      next(error);
    }
  }
);

/**
 * ============================================================
 * RESET PASSWORD
 * ============================================================
 */
usersRouter.patch(
  '/users/:id/reset-password',
  authMiddleware,
  requireRole('gerant'),
  async (request: AuthRequest, response, next) => {
    try {
      const id = Number(request.params.id);

      if (!Number.isInteger(id) || id <= 0) {
        response.status(400).json({
          message: 'ID utilisateur invalide.',
        });
        return;
      }

      const input =
        resetPasswordSchema.parse(
          request.body
        );

      const magasinId =
        request.user?.magasinId;

      let sql = `
        SELECT id
        FROM user
        WHERE id = ?
      `;

      const params: any[] = [id];

      if (
        magasinId !== null &&
        magasinId !== undefined
      ) {
        sql += ` AND magasinId = ? `;
        params.push(magasinId);
      }

      sql += ` LIMIT 1 `;

      const [rows] = await db.query(
        sql,
        params
      );

      const users = rows as any[];

      if (users.length === 0) {
        response.status(404).json({
          message: 'Utilisateur introuvable.',
        });
        return;
      }

      /**
       * Nouveau hash
       */
      const passwordHash =
        await bcrypt.hash(
          input.newPassword,
          12
        );

      await db.query(
        `
        UPDATE user
        SET passwordHash = ?
        WHERE id = ?
        `,
        [passwordHash, id]
      );

      response.json({
        message:
          'Mot de passe réinitialisé.',
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * ============================================================
 * CHANGE PASSWORD
 * ============================================================
 */
router.patch(
  '/change-password',
  authMiddleware,
  async (request: AuthRequest, response, next) => {
    try {
      const input =
        changePasswordSchema.parse(
          request.body
        );

      const userId =
        request.user!.id;

      const [rows] = await db.query(
        `
        SELECT
          id,
          passwordHash
        FROM user
        WHERE id = ?
        LIMIT 1
        `,
        [userId]
      );

      const users = rows as any[];

      if (users.length === 0) {
        response.status(404).json({
          message: 'Utilisateur introuvable.',
        });
        return;
      }

      const user = users[0];

      /**
       * Vérifier ancien mot de passe
       */
      const passwordValid =
        await bcrypt.compare(
          input.currentPassword,
          user.passwordHash
        );

      if (!passwordValid) {
        response.status(400).json({
          message:
            'Mot de passe actuel incorrect.',
        });
        return;
      }

      /**
       * Nouveau mot de passe
       */
      const passwordHash =
        await bcrypt.hash(
          input.newPassword,
          12
        );

      await db.query(
        `
        UPDATE user
        SET passwordHash = ?
        WHERE id = ?
        `,
        [passwordHash, userId]
      );

      response.json({
        message:
          'Mot de passe modifié.',
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * ============================================================
 * DELETE / DISABLE USER
 * ============================================================
 */
usersRouter.delete(
  '/users/:id',
  authMiddleware,
  requireRole('gerant'),
  async (request: AuthRequest, response, next) => {
    try {
      const id = Number(request.params.id);

      if (!Number.isInteger(id) || id <= 0) {
        response.status(400).json({
          message: 'ID utilisateur invalide.',
        });
        return;
      }

      /**
       * Empêcher un gérant de désactiver son compte
       */
      if (request.user?.id === id) {
        response.status(400).json({
          message:
            'Vous ne pouvez pas désactiver votre propre compte.',
        });
        return;
      }

      const magasinId =
        request.user?.magasinId;

      let sql = `
        SELECT id
        FROM user
        WHERE id = ?
      `;

      const params: any[] = [id];

      if (
        magasinId !== null &&
        magasinId !== undefined
      ) {
        sql += ` AND magasinId = ? `;
        params.push(magasinId);
      }

      sql += ` LIMIT 1 `;

      const [rows] = await db.query(
        sql,
        params
      );

      const users = rows as any[];

      if (users.length === 0) {
        response.status(404).json({
          message: 'Utilisateur introuvable.',
        });
        return;
      }

      /**
       * Désactivation logique
       * On ne supprime pas réellement l'utilisateur.
       */
      await db.query(
        `
        UPDATE user
        SET actif = 0
        WHERE id = ?
        `,
        [id]
      );

      response.status(204).send();
    } catch (error) {
      next(error);
    }
  }
);

export default router;
